# VC-PLATFORM-API

## Dependency

```bash
npm, nodeJS, expressJS, AWS, Regex, jsonwebtoken, request, aws-sdk, crypto,
cron, fs, morgan,, mysql
```

## Commands

```javascript
start: NODE_ENV=DEV node ./bin/www
start:testing: NODE_ENV=TEST node ./bin/www
start:production: NODE_ENV=PROD node ./bin/www
```

## Important Links

