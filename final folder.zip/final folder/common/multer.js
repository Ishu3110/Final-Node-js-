const multer = require('multer');
var fs = require('fs');

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public/uploads');
    // cb(null, 'public/uploads');
    // console.log('filename', file.originalname);
  },
  filename: function (req, file, cb) {
    cb(null, 'img' + '-' + Date.now() + file.originalname);
  },
});

var upload = multer({
  limits: { fieldNameSize: 1000000, fieldSize: 25 * 1024 * 1024 },
  storage: storage,
});
module.exports = upload;
