module.exports = {
    port: 3000,
    databaseHost: 'localhost',
    databaseUser: 'root',
    databasePassword: 'Training@123',
    databaseName: 'ur-link',
    secret_key: 'my_super_secret'
};
