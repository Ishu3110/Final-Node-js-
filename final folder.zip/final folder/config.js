require('dotenv').config();

module.exports = {
 
  env:process.env.NODE_ENV,
  databaseHost: process.env.DATABASE_HOST,
  databaseUser: process.env.DATABASE_USER,
  databasePassword: process.env.DATABASE_PASSWORD,
  databaseName: process.env.DATABASE_NAME,
  
  secret_key: process.env.SECRET_KEY,

  cryptokey: process.env.CRYPTO_KEY,
  tokenkey: process.env.TOKEN_KEY,
  port: process.env.PORT,
  
 
}
