const object = require('./user');
const functions = require('../../common/functions');

const controller = {


    registration: async (req, res) => {
        try {
            const registrationDetails = await object
                .userService()
                .userRegistration(req, res);
            res.send(
                functions.responseGenerator(
                    registrationDetails.code,
                    registrationDetails.message,
                    registrationDetails.data
                )
            );
        } catch (error) {
            res.send(
                functions.responseGenerator(
                    error.code,
                    error.message,
                    error.data
                )
            );
        }
    }
}

module.exports = controller;