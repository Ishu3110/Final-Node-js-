const router = require('express').Router();
const api = require('./controller');


router.post('/registration', api.registration);

module.exports = router;