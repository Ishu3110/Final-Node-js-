const con = require('../../common/mysql');
const functions = require('../../common/functions');
const statusCode = require('../../common/statusCode');
const message = require('../../common/message');
const fs = require('fs');
const user = require('../../api/v1.0');


class UserService {



    async userRegistration(req, res) {
        try {

            const requestBody = req.body;
            let role_id = requestBody.role_id;
            let first_name = requestBody.first_name;
            let last_name = requestBody.last_name;
            let user_name = requestBody.user_name;
            let user_bio = requestBody.user_bio;
            let user_email = requestBody.user_email;
            let user_password = requestBody.user_password;
            const getUserDetailQuery = `select * from tbluser where user_email= ?`;
            const result = await query(getUserDetailQuery, [user_email]);
            console.log("got the result", result)
            console.log(Object.keys(result).length)
            if (result.length > 0) {
                return {
                    code: code.success,
                    message: 'Already Exist',
                    data: [],
                };
            }
            else {
                var new_password = await functions.encryptPassword(user_password);
                user_password = new_password;
                const insertQuery = 'insert into tbluser (role_id,first_name,last_name,user_name,user_bio,user_email,user_password) values (?,?,?,?,?,?,?)';
                const insertResponse = await query(insertQuery, [role_id, first_name, last_name, user_name, user_bio, user_email, user_password]);
                console.log(insertResponse);
                const getUserDetailQuery1 = 'select * from tbluser where user_email= ?';
                const result1 = await query(getUserDetailQuery1, [user_email]);
                var etoken = await functions.tokenEncrypt(result1[0])
                const finalResult = {
                    "user_information": result1[0],
                    "token": etoken
                }
                console.log("result is here", finalResult);
                return {
                    code: code.success,
                    message: "Singup SuccessFull",
                    data: finalResult
                };
            }
        } catch (error) {
            return {
                code: code.unexceptedError,
                message: message.tryCatch,
                data: error.message,
            };
        }

    }
}





module.exports = {
    userService: function () {
        return new UserService();
    },
};