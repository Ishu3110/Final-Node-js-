const con = require('../../../../../common/mysql');
const util = require('util');
const query = util.promisify(con.query).bind(con);
const statusCode = require('../../../../../common/statusCode');


class UserDatabase {
  /**
   * @description - Function to check if user data already exists in database or not
   * @param {*} info - user data
   */
  async checkIfUserExists(info) {
    try {
      const sqlSelectQuery = `SELECT * FROM user where email_address = ?`;
      const details = await query(sqlSelectQuery, [
        info.email_address,
        info.ip_address,
      ]);
      return details;
    } catch (error) {
      throw {
        code: statusCode.internal_server_error,
        message: error.message,
        data: JSON.stringify(error),
      };
    }
  }

}

module.exports = {
  userDatabase: function () {
    return new UserDatabase();
  },
};
