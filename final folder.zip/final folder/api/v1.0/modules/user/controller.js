const object = require('./user');
const functions = require('../../../../common/functions');

const controller = {
  // Login Controller
  login: async (req, res) => {
    try {
      const loginData = await object
        .userService()
        .login(req.body);
      res.send(
        functions.responseGenerator(
          loginData.code,
          loginData.message,
          loginData.data
        )
      );
    } catch (error) {
      res.send(
        functions.responseGenerator(error.code, error.message, error.data)
      );
    }
  },

  // Registration of User
  registration: async (req, res) => {
    try {
      console.log(req.body)
      console.log(req.files.img.name)
      const registrationDetails = await object
        .userService()
        .userRegistration(req, res);
      res.send(
        functions.responseGenerator(
          registrationDetails.code,
          registrationDetails.message,
          registrationDetails.data
        )
      );
    } catch (error) {
      res.send(
        functions.responseGenerator(
          error.code,
          error.message,
          error.data
        )
      );
    }
  },



  //SignIn
  signIn: async (req, res) => {
    try {
      const userDetails = await object
        .userService()
        .signInUser(req, res);

      res.send(
        functions.responseGenerator(
          userDetails.code,
          userDetails.message,
          userDetails.data
        )
      );
    } catch (error) {
      res.send(
        functions.responseGenerator(
          error.code,
          error.message,
          error.data
        )
      );
    }
  },


  //forgot password
  forgotP: async (req, res) => {
    try {
      const userDetails = await object
        .userService()
        .forgetPasswordUser(req, res);

      res.send(
        functions.responseGenerator(
          userDetails.code,
          userDetails.message,
          userDetails.data
        )
      );
    } catch (error) {
      res.send(
        functions.responseGenerator(error.code, error.message, error.data)
      );
    }
  },



  //update user profile
  updateProfile: async (req, res) => {
    try {
      console.log("req: ", req.body);
      const userDetails = await object
        .userService()
        .updateUserProfile(res.locals.tokenInfo, req.body);
      res.send(
        functions.responseGenerator(
          userDetails.code,
          userDetails.message,
          userDetails.data
        )
      )
    } catch (error) {
      res.send(
        functions.responseGenerator(error.code, error.message, error.data)
      );
    }

  },

  // Reset Password
  passwordReset: async (req, res) => {
    try {
      console.log("req: ", req.body);
      const userInfo = await object
        .userService()
        .updateUserPassword(res.locals.tokenInfo, req.body);
      res.send(
        functions.responseGenerator(
          userInfo.code,
          userInfo.message,
          userInfo.data
        )
      )
    } catch (error) {
      res.send(
        functions.responseGenerator(error.code, error.message, error.data)
      );
    }

  }

};


module.exports = controller;
