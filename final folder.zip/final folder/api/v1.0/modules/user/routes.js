const router = require('express').Router();
const api = require('./controller');
const auth = require('../../../../common/authentication');

router.post('/login', api.login);


router.post('/registration', api.registration);
router.post('/signIn', api.signIn);
router.post('/forgotPassword', api.forgotP);

router.post('/updateUserProfile', auth.validateToken, api.updateProfile);

router.post('/resetPassword', auth.validateToken, api.passwordReset);



module.exports = router;