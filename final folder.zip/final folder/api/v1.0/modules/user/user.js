const con = require('../../../../common/mysql');
const util = require('util');
const query = util.promisify(con.query).bind(con);
const functions = require('../../../../common/functions');
const config = require('../../../../config');
const validator = require('validator');
const statusCode = require('../../../../common/statusCode');
const message = require('../../../../common/message');

const multer = require('multer');

const userDb = require(`./database/mysql`);
const authenticationController = require('../../../../common/authentication');
class UserService {

  /**
   * @description - Function to login the user
   * @param {*} info - request body data of user to login
   */
  async login(info) {
    try {
      const userData = await userDb.userDatabase().checkIfUserExists(info);
      return {
        code: statusCode.success,
        message: message.success,
        data: userData,
      };
    } catch (error) {
      return {
        code: statusCode.internal_server_error,
        message: error.message,
        data: JSON.stringify(error),
      };
    }
  }



  async userRegistration(req, res) {
    try {

      const requestBody = req.body;
      let role_id = requestBody.role_id;
      let first_name = requestBody.first_name;
      let last_name = requestBody.last_name;
      let user_name = requestBody.user_name;
      let user_bio = requestBody.user_bio;
      let user_email = requestBody.user_email;
      let user_password = requestBody.user_password;
      const requestFile = req.files.img.name;
      let user_image = requestFile;
      // console.log(req);

      const getUserDetailQuery = `select * from tbluser where user_email= ?`;
      const result = await query(getUserDetailQuery, [user_email]);
      console.log("got the result", result)
      console.log(Object.keys(result).length)
      if (result.length > 0) {
        return {
          code: statusCode.success,
          message: 'Already Exist',
          data: [],
        };
      }
      else {
        var new_password = await functions.encryptPassword(user_password);
        user_password = new_password;
        let path = '/uploads/' + user_image;
        const insertQuery = 'insert into tbluser (role_id,first_name,last_name,user_name,user_bio,user_email,user_password,user_image) values (?,?,?,?,?,?,?,?)';
        const insertResponse = await query(insertQuery, [role_id, first_name, last_name, user_name, user_bio, user_email, user_password, path]);
        console.log(insertResponse);
        const getUserDetailQuery1 = 'select * from tbluser where user_email= ?';
        const result1 = await query(getUserDetailQuery1, [user_email]);

        if (statusCode.success) {
          var mailOptions = {
            from: 'IshwariT@winjit.com',
            to: user_email,
            subject: 'Registration Successfull',
            text: "Congratulations you have been successfully Registered"
          };
          let mailResponse = await functions.sendEmail(mailOptions);
          // functions.sendEmail(mailOptions, function (error, info) {
          //   if (error) {
          //     console.log('error :', error);
          //   } else {
          //     response.send("email sent");
          //     console.log('Email sent: ' + info.response);
          //   }
          // });
          // return {
          //   code: code.success,
          //   message: 'Email has been sent successfully',
          //   data: result
          // };

          return {
            code: statusCode.success,
            message: "Registration SuccessFull",
            data: result1
          };
        }
        else {
          console.log("mail can't be sent");
        }

      }

      //console.log("result is here", finalResult);

    } catch (error) {
      return {
        code: statusCode.bad_request,
        message: message.tryCatch,
        data: error.message,
      };
    }

  }




  // SignIn function
  async signInUser(req, res) {
    try {
      const requestBody = req.body;
      let user_email = requestBody.user_email;
      let user_password = requestBody.user_paswword;
      const getUserDetailQuery = 'Select * from tbluser where user_email= ?';
      var result = await query(getUserDetailQuery, [user_email]);
      var etoken = await functions.tokenEncrypt(result[0])
      //console.log("etoken", etoken);
      const finalResult = {
        "user_information": result[0],
        "token": etoken
      }

      //delete password from result
      /// delete result[0].user_password;
      // console.log("result", result)
      if (result.length < 1) {
        return {
          code: statusCode.success,
          message: 'User does not exist',
          data: [],
        };
      }
      else {
        result = JSON.parse(JSON.stringify(result));
        // var userTokenDetails = result
        var DBpassword = result[0].user_password;
        //console.log("old password : ", DBpassword);
        //console.log("working correctly uptil here");
        // var new_password = functions.decryptPassword(user_password)
        var new_password = functions.decryptPassword(DBpassword)
        //console.log("new password:", new_password);


        let D_Password = result.user_password;
        //let D_Password = result.new_password;
        //console.log(D_Password);
        if (user_password === D_Password) {
          delete result[0].user_password;
          console.log("finalResult", finalResult);
          return {

            code: statusCode.success,
            message: 'Sign In Successful',
            data: finalResult
          };
        }
        else {
          return {
            code: statusCode.success,
            message: 'Invalid Details',
            data: [],
          };
        }

      }
    } catch (error) {
      return {
        code: statusCode.bad_request,
        message: message.tryCatch,
        data: error.message,
      };
    }
  }





  //forgot password
  async forgetPasswordUser(req, res) {
    try {
      const requestBody = req.body;
      console.log(requestBody);
      var user_email = requestBody.user_email;
      console.log(user_email);
      const getDetails = 'select * from tbluser where user_email= ?';
      const result = await query(getDetails, [user_email]);
      console.log("result is:  ", result);
      var DBpassword = result[0].user_password;
      console.log("DBpassword", DBpassword);
      var new_password = functions.decryptPassword(DBpassword)
      console.log("new_password", new_password);
      var finalDetails = {
        "user_email": user_email,
        "user_password": new_password
      }
      console.log(finalDetails);
      if (result.length > 0) {
        console.log("email id exist");

        var mailOptions = {
          from: 'IshwariT@winjit.com',
          to: user_email,
          subject: 'Forgot Password',
          text: JSON.stringify(finalDetails)
        };


        // console.log("mailoptions :", mailOptions);
        let mailResponse = await functions.sendEmail(mailOptions);
        return {
          code: statusCode.success,
          message: 'Email has been sent successfully',
          data: finalDetails
        };
      }
      else {
        console.log("check details");
        return {
          code: statusCode.bad_request,
          message: 'Invalid Details',
          data: [],
        };
      }
    } catch (error) {
      return {
        code: statusCode.not_acceptable,
        message: 'Invalid Details',
        data: [],
      }
    }
  }



  async updateUserProfile(tokenInfo, req) {
    try {
      var user_email = tokenInfo.user_email;
      var user_password = tokenInfo.user_password;
      var first_name = req.first_name;
      var last_name = req.last_name;
      var user_name = req.user_name;
      var user_bio = req.user_bio;
      var userQuery = "UPDATE tbluser SET first_name = '" + first_name + "',last_name='" + last_name + "',user_name='" + user_name + "',user_bio ='" + user_bio + "'WHERE role_id = '" + tokenInfo.role_id + "' and id ='" + tokenInfo.id + "' ";
      console.log(userQuery);
      const result1 = await query(userQuery, [user_email][user_password]);
      return {
        code: statusCode.success,
        message: 'Successfull',
        data: result1
      };
    } catch (error) {
      return {
        code: statusCode.not_acceptable,
        message: 'Invalid Details',
        data: [],
      }
    }
  }



  async updateUserPassword(tokenInfo, req) {
    try {
      var mailId = tokenInfo.user_email;
      //  var user_password = req.user_password;
      console.log(tokenInfo.user_email);
      const getDetails = `Select * from tbluser where user_email= ?`;
      const resultOfDetails = await query(getDetails, [mailId]);
      //console.log("get deatils :         ", getDetails)
      console.log("Details are: ", resultOfDetails);
      if (resultOfDetails.length > 0) {
        console.log("heyyy");
        var decry_P = functions.encryptPassword(req.user_password);
        console.log("dec  :", decry_P);
        //user_password = decry_P;
        // console.log("new password   :", user_password);
        var Query1 = "UPDATE tbluser set user_password = '" + decry_P + "' where user_email = '" + mailId + "'";
        console.log("Query1  :", Query1);
        let values = await query(Query1);
        console.log("values   :", values);
        const getUserDetailQuery = `Select * from tbluser where user_email= ?`;
        const r = await query(getUserDetailQuery, [mailId]);
        console.log("r.....", r);
        // const getUserDetailQuery = 'Select * from tbluser where user_email = ' + mailId + ' ';
        // console.log("this query  :", getUserDetailQuery);

        // var finalUpdation = await query(getUserDetailQuery);
        //console.log("hello");
        //console.log("final result ...........", finalUpdation);

        return {
          code: statusCode.success,
          message: 'success!!!!!',
          data: r
        };
      }
      else {
        console.log("Someone attempt to login  your account");
      }

      //} 
    } catch (error) {
      return {
        code: statusCode.not_acceptable,
        message: 'Invalid Details',
        data: [],
      }
    }

  }

















}




module.exports = {
  userService: function () {
    return new UserService();
  },
};
